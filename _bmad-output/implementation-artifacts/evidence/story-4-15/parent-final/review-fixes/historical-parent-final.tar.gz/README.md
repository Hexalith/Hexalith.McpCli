# Story 4.15 authoritative publication and qualification

The finished rule and migration plan are published on authoritative AI.Tools
`main` at `68e60375eb298854611b2fefd1dfef95bad7a8c9`, directly integrated
after `3f194e17174994d308ec84af9ee2b5aa68674d0d`.
[Publication receipts](upstream-publication.json) retain the exact commit,
successful owning pinned commitlint result, push and matching remote-main
identity. This is a published main revision, not an open PR.

The [baseline integration receipt](baseline-integration.json) records the clean
root-declared AI.Tools reference's fast-forward to that exact revision. Local
entry points remain byte-identical. [Final qualification](qualification.json)
passes all four matrix rows, including three fresh drift controls, the missing
plan negative control, exact inventory preservation and both unchanged paired
release refusals. Its candidate gitlink records the published revision; the root
commit and final workflow review follow this qualification.

## Local preparation before publication

The current AI.Tools candidate contains migration plan **1.0.0**, its baseline
link, README guidance, and the pinned commitlint prerequisite needed to publish
the upstream change. The plan and policy preserve the six source-pinned
inventories, five frozen module CLIs, the Projects plug-in, Parties' legacy
server and the EventStore Admin successor inventory gap. No operation or
retirement approval changes.

The [initial packet](../README.md) retains the original three-document candidate
and its offline checks. This packet supersedes that candidate's README and adds
`package.json`, `package-lock.json` and `commitlint.config.mjs`. The initial
missing-tooling finding is resolved: offline lock generation and
`npm ci --offline --ignore-scripts --no-audit --no-fund` succeeded, installing
71 development-only packages. CLI and conventional policy are pinned to 21.2.2,
matching McpCli's direct tooling versions; the lock binds the complete closure.
[Commit validation](commitlint.json) records the actual pinned CLI, nonempty
effective rules, accepted exact message, and two rejected negative controls.
No commit had been created when these local checks were captured.

The local candidate was prepared in the owning
`/home/administrator/projects/hexalith/aitools` checkout, based on
`3f194e17174994d308ec84af9ee2b5aa68674d0d`. The historical
[local verification](verification.json) correctly kept completion false before
publication. It is superseded for publication and containment by the receipts
above. No fresh hosted, live or .NET qualification is claimed for this
documentation and development-tooling change.

This packet records the local candidate before publication. The user's approved
spec includes authoritative upstream integration and its containing root
baseline; that authorization takes precedence over the skill's generic
implementation-stage no-remote rule. Publication receipts and final review
evidence record completion separately from these local observations.
